/**
 * Логика взаимодействия с агентом Айра
 */

class AgentDialog {
    constructor() {
        this.messages = [];
        this.currentDistrict = null;
        this.currentEmotion = null;
        this.sessionContext = null;
    }
    
    startDialog(greeting, districtInfo) {
        const messagesContainer = document.getElementById('dialog-messages');
        if (messagesContainer) {
            messagesContainer.innerHTML = '';
        }
        
        this.messages = [];
        
        // Добавляем приветствие
        if (greeting) {
            this.addMessage(greeting, 'agent');
        }
        
        // Устанавливаем фокус на поле ввода
        const input = document.getElementById('dialog-input');
        if (input) {
            input.focus();
        }
        
        // Перепривязываем обработчики при старте диалога
        setupAgentDialogHandlers();
    }
    
    addMessage(text, sender) {
        const messagesContainer = document.getElementById('dialog-messages');
        if (!messagesContainer) return;
        
        const messageEl = document.createElement('div');
        messageEl.className = `message ${sender}`;
        
        const textEl = document.createElement('div');
        textEl.className = 'message-text';
        textEl.textContent = text;
        
        messageEl.appendChild(textEl);
        messagesContainer.appendChild(messageEl);
        
        // Прокрутка вниз
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Сохраняем сообщение
        this.messages.push({ text, sender });
    }
    
    async sendMessage() {
        console.log('sendMessage called');
        const input = document.getElementById('dialog-input');
        if (!input) {
            console.error('Input field not found');
            return;
        }
        
        const message = input.value.trim();
        if (!message) {
            console.log('Empty message, ignoring');
            return;
        }
        
        console.log('Sending message:', message);
        
        // Добавляем сообщение игрока
        this.addMessage(message, 'player');
        
        // Очищаем поле ввода
        input.value = '';
        
        // Показываем индикатор загрузки
        this.showLoading();
        
        // Блокируем кнопку отправки
        const sendBtn = document.getElementById('send-message-btn');
        if (sendBtn) {
            sendBtn.disabled = true;
            sendBtn.textContent = 'Отправка...';
        }
        
        try {
            // Отправляем на сервер
            const response = await fetch('/api/agent/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message: message,
                    district: this.currentDistrict,
                    emotion: this.currentEmotion,
                    session_context: this.sessionContext
                })
            });
            
            const data = await response.json();
            
            this.hideLoading();
            
            // Разблокируем кнопку
            const sendBtn = document.getElementById('send-message-btn');
            if (sendBtn) {
                sendBtn.disabled = false;
                sendBtn.textContent = 'Отправить';
            }
            
            if (data.success) {
                // Проверяем кризисную ситуацию
                if (data.is_crisis) {
                    this.handleCrisis(data);
                    return;
                }
                
                // Добавляем ответ агента
                this.addMessage(data.response, 'agent');
                
                // Проверяем, нужно ли переходить к мини-играм
                this.checkForMinigameTransition(data.response);
            } else {
                this.addMessage('Произошла ошибка. Попробуй еще раз.', 'agent');
            }
        } catch (error) {
            console.error('Ошибка отправки сообщения:', error);
            this.hideLoading();
            
            // Разблокируем кнопку при ошибке
            const sendBtn = document.getElementById('send-message-btn');
            if (sendBtn) {
                sendBtn.disabled = false;
                sendBtn.textContent = 'Отправить';
            }
            
            this.addMessage('Ошибка соединения. Проверь интернет.', 'agent');
        }
    }
    
    showLoading() {
        const messagesContainer = document.getElementById('dialog-messages');
        if (!messagesContainer) return;
        
        const loadingEl = document.createElement('div');
        loadingEl.className = 'message agent';
        loadingEl.id = 'agent-loading';
        loadingEl.innerHTML = '<div class="message-text">Айра печатает<span class="loading-dots">...</span></div>';
        
        messagesContainer.appendChild(loadingEl);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    hideLoading() {
        const loadingEl = document.getElementById('agent-loading');
        if (loadingEl) {
            loadingEl.remove();
        }
    }
    
    handleCrisis(data) {
        // Показываем кризисный экран
        const crisisScreen = document.getElementById('crisis-screen');
        const crisisMessage = document.getElementById('crisis-message');
        const helplinesList = document.getElementById('helplines-list');
        
        if (crisisScreen && crisisMessage) {
            crisisMessage.textContent = data.response;
            
            // Добавляем горячие линии
            if (helplinesList && data.helplines) {
                helplinesList.innerHTML = data.helplines.map(helpline => `
                    <div class="helpline-item">
                        <div class="helpline-name">${helpline.name}</div>
                        <div class="helpline-phone">${helpline.phone}</div>
                        <div class="helpline-description">${helpline.description}</div>
                    </div>
                `).join('');
            }
            
            if (window.game) {
                window.game.showScreen('crisis-screen');
            }
        }
    }
    
    checkForMinigameTransition(response) {
        // Проверяем ключевые слова для перехода к мини-играм
        const lowerResponse = response.toLowerCase();
        
        if (lowerResponse.includes('опор') || 
            lowerResponse.includes('сфер') || 
            lowerResponse.includes('действие') ||
            lowerResponse.includes('комфорт')) {
            
            // Переходим к мини-игре сферы через 3 секунды
            setTimeout(() => {
                if (window.game) {
                    window.game.showScreen('sphere-minigame');
                }
            }, 3000);
        } else if (lowerResponse.includes('дыхан') || 
                   lowerResponse.includes('заземл') ||
                   lowerResponse.includes('пауз')) {
            
            // Переходим к дыханию через 3 секунды
            setTimeout(() => {
                if (window.game) {
                    window.game.showScreen('breathing-minigame');
                    if (window.minigames) {
                        window.minigames.initBreathingGame();
                    }
                }
            }, 3000);
        }
    }
    
    skipDialog() {
        // Пропускаем диалог и переходим к мини-играм
        if (window.game) {
            window.game.showScreen('sphere-minigame');
        }
    }
}

// Функция для привязки обработчиков событий
function setupAgentDialogHandlers() {
    // Обработчик отправки сообщения - используем делегирование событий
    const dialogScreen = document.getElementById('agent-dialog');
    
    if (dialogScreen) {
        // Удаляем старые обработчики
        const sendBtn = document.getElementById('send-message-btn');
        const input = document.getElementById('dialog-input');
        const skipBtn = document.getElementById('skip-dialog-btn');
        
        // Используем делегирование событий на уровне экрана
        dialogScreen.addEventListener('click', (e) => {
            if (e.target && e.target.id === 'send-message-btn') {
                e.preventDefault();
                e.stopPropagation();
                console.log('Send button clicked via delegation');
                if (window.agentDialog) {
                    window.agentDialog.sendMessage();
                } else {
                    console.error('agentDialog not initialized');
                    alert('Диалог не инициализирован. Перезагрузите страницу.');
                }
            }
            
            if (e.target && e.target.id === 'skip-dialog-btn') {
                e.preventDefault();
                if (window.agentDialog) {
                    window.agentDialog.skipDialog();
                }
            }
        });
        
        // Обработка Enter в поле ввода
        if (input) {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    console.log('Enter pressed in input');
                    if (window.agentDialog) {
                        window.agentDialog.sendMessage();
                    } else {
                        console.error('agentDialog not initialized');
                    }
                }
            });
        }
        
        console.log('Agent dialog handlers setup complete');
    } else {
        console.warn('Dialog screen not found');
    }
}

// Инициализация
document.addEventListener('DOMContentLoaded', () => {
    window.agentDialog = new AgentDialog();
    
    // Привязываем обработчики сразу
    setupAgentDialogHandlers();
    
    // Также привязываем обработчики при показе экрана диалога
    const dialogScreen = document.getElementById('agent-dialog');
    if (dialogScreen) {
        // Используем MutationObserver для отслеживания появления экрана
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.target.classList.contains('active')) {
                    // Экран стал активным, перепривязываем обработчики
                    setTimeout(() => {
                        setupAgentDialogHandlers();
                    }, 100);
                }
            });
        });
        observer.observe(dialogScreen, { attributes: true, attributeFilter: ['class'] });
    }
    
    // Обновляем контекст при начале сессии
    // Это будет выполнено позже, когда game.js загрузится
    setTimeout(() => {
        if (window.game && window.agentDialog) {
            const originalStartSession = window.game.startSession;
            if (originalStartSession) {
                window.game.startSession = async function(districtKey) {
                    await originalStartSession.call(this, districtKey);
                    
                    if (window.agentDialog) {
                        window.agentDialog.currentDistrict = districtKey;
                        window.agentDialog.currentEmotion = this.currentEmotion;
                        window.agentDialog.sessionContext = {
                            district: districtKey,
                            emotion: this.currentEmotion,
                            intensity: this.currentIntensity
                        };
                    }
                };
            }
        }
    }, 500);
});

// Добавляем стили для точек загрузки
const style = document.createElement('style');
style.textContent = `
    .loading-dots {
        display: inline-block;
        animation: loadingDots 1.5s steps(4, end) infinite;
    }
    
    @keyframes loadingDots {
        0%, 20% { content: '.'; }
        40% { content: '..'; }
        60%, 100% { content: '...'; }
    }
`;
document.head.appendChild(style);

