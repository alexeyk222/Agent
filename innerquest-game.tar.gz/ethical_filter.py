"""
Этический фильтр для обнаружения кризисных ситуаций
"""
import re
from typing import Tuple


class EthicalFilter:
    """Фильтр для обнаружения кризисных сообщений"""
    
    # Триггерные фразы и паттерны
    CRISIS_KEYWORDS = [
        r'не\s+хочу\s+жить',
        r'хочу\s+умереть',
        r'покончить\s+с\s+собой',
        r'суицид',
        r'самоубийств',
        r'кончить\s+жизнь',
        r'убить\s+себя',
        r'больше\s+не\s+выдержу',
        r'всё\s+бесполезно',
        r'лучше\s+бы\s+меня\s+не\s+было',
        r'не\s+вижу\s+смысла',
        r'всё\s+кончено',
        r'конец\s+всему',
        r'не\s+выдержу',
        r'не\s+могу\s+больше',
        r'хватит\s+всё',
    ]
    
    # Горячие линии помощи (Россия)
    HELPLINES = [
        {
            'name': 'Телефон доверия',
            'phone': '8-800-2000-122',
            'description': 'Единый общероссийский телефон доверия для детей, подростков и их родителей'
        },
        {
            'name': 'Кризисная линия помощи',
            'phone': '8-495-989-50-50',
            'description': 'Московская служба психологической помощи'
        },
        {
            'name': 'Телефон доверия МЧС',
            'phone': '8-495-989-50-50',
            'description': 'Психологическая помощь в кризисных ситуациях'
        }
    ]
    
    def __init__(self):
        # Компилируем регулярные выражения
        self.patterns = [re.compile(pattern, re.IGNORECASE) for pattern in self.CRISIS_KEYWORDS]
    
    def check_message(self, message: str) -> Tuple[bool, str]:
        """
        Проверяет сообщение на кризисные признаки
        
        Returns:
            (is_crisis, response_message)
        """
        message_lower = message.lower()
        
        for pattern in self.patterns:
            if pattern.search(message_lower):
                return True, self._generate_crisis_response()
        
        return False, ""
    
    def _generate_crisis_response(self) -> str:
        """Генерирует ответ с информацией о помощи"""
        response = "Я вижу, что тебе сейчас очень тяжело. Это не игра, и я не могу помочь в такой ситуации.\n\n"
        response += "Пожалуйста, обратись за профессиональной помощью:\n\n"
        
        for helpline in self.HELPLINES:
            response += f"📞 {helpline['name']}: {helpline['phone']}\n"
            response += f"   {helpline['description']}\n\n"
        
        response += "Ты не один. Есть люди, которые готовы помочь.\n"
        response += "Игра будет заблокирована до тех пор, пока ты не обратишься за помощью."
        
        return response
    
    def get_helplines_json(self) -> list:
        """Возвращает список горячих линий в формате JSON"""
        return self.HELPLINES

